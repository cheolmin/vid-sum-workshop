import json
import boto3
import urllib
import botocore
import logging
import time
import requests

logger = logging.getLogger(__name__)

transcribe_client = boto3.client("transcribe")
s3 = boto3.client('s3')

def get_job(job_name):
    
    try:
        response = transcribe_client.get_transcription_job(
            TranscriptionJobName=job_name
        )
        job = response["TranscriptionJob"]
        logger.info("Got job %s.", job["TranscriptionJobName"])
    except botocore.exceptions.ClientError:
        logger.exception("Couldn't get job %s.", job_name)
        return None
    else:
        return job
        
def transcribe_file(job_name, file_uri, transcribe_client):
    transcribe_client.start_transcription_job(
        TranscriptionJobName=job_name,
        Media={"MediaFileUri": file_uri},
        MediaFormat="mp4",
        LanguageCode="ko-KR",
    )

    max_tries = 60
    while max_tries > 0:
        max_tries -= 1
        job = transcribe_client.get_transcription_job(TranscriptionJobName=job_name)
        job_status = job["TranscriptionJob"]["TranscriptionJobStatus"]
        if job_status in ["COMPLETED", "FAILED"]:
            print(f"Job {job_name} is {job_status}.")
            if job_status == "COMPLETED":
                print(
                    f"Download the transcript from\n"
                    f"\t{job['TranscriptionJob']['Transcript']['TranscriptFileUri']}."
                )
            break
        else:
            print(f"Waiting for {job_name}. Current status is {job_status}.")
        time.sleep(10)
    #transcript_vocab_table = requests.get(
    #    job["Transcript"]["TranscriptFileUri"]
    #).json()
    return True

def run_transcribe(transcribe_job_name, file_uri, debug=False):
    if debug == False:
        if transcribe_job_name is not None:
            transcribe_result = transcribe_file(transcribe_job_name, file_uri, transcribe_client)
    job_simple = get_job(transcribe_job_name)
    transcript_simple = requests.get(
        job_simple["Transcript"]["TranscriptFileUri"]
    ).json()

    return transcript_simple["results"]  # ["transcripts"]
    
def upload_file_s3(bucket, file_name, file):
    s3 = boto3.client('s3')
    encode_file = json.dumps(file, indent=4, ensure_ascii=False)
    try:
        s3.put_object(Bucket=bucket, Key=file_name, Body=encode_file)
        return True
    except: 
        return False

def lambda_handler(event, context):
    # TODO implement
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    
    input_file = key.split('/')[-1]
    
    transcribe_job_name = 'job_' + input_file.split('.')[0]

    file_uri = 'https://s3.us-east-1.amazonaws.com/{}/{}'.format(bucket, key)
    if get_job(transcribe_job_name) is None:
        transcribe_result = run_transcribe(transcribe_job_name, file_uri, debug=False)
    else:
        transcribe_result = run_transcribe(transcribe_job_name, file_uri, debug=True)

    print(transcribe_result)
    
    save = upload_file_s3(bucket, 'transcribe/'+input_file.split('.')[0]+'.json', transcribe_result)
    
    print(save)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
