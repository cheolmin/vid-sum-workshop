import json
import cv2
import urllib
import boto3
import base64

s3 = boto3.resource('s3')
sagemaker = boto3.client('sagemaker-runtime')
blip_endpoint = 'blip-2-gpu'
SAMPLE_EVERY_SEC = 10

def encode_image(img):
    #with open(img_file, "rb") as image_file:

    #retval, buffer = cv2.imencode('.jpg', img)
    #jpg_as_text = base64.b64encode(buffer)
    string = base64.b64encode(cv2.imencode('.jpg', img)[1]).decode()

    #img_str = base64.b64encode(img)
    #base64_string = img_str.decode("latin1")
    return string

def run_inference(endpoint_name, inputs):
    response = sagemaker.invoke_endpoint(
        EndpointName=endpoint_name, Body=json.dumps(inputs)
    )
    return response["Body"].read().decode('utf-8')

def extract_frames(bucket, key, video_path, SAMPLE_EVERY_SEC=2, enable = True, method = ""):
    frames = []
    inference_results = []
    prompt = "Question: What scene is this picture? Answer:"
    save_path = key.split('/')[-1]
    save_path = save_path.split('.')[0]
    
    cap = cv2.VideoCapture(video_path)

    n_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
    print(cv2.CAP_PROP_FPS)
    fps = cap.get(cv2.CAP_PROP_FPS)

    video_len = n_frames / fps

    print(f'Video length {video_len:.2f} seconds!')
    last_collected = -1

    if enable:
        cnt = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            timestamp = cap.get(cv2.CAP_PROP_POS_MSEC)
            second = timestamp // 1000

            if second % SAMPLE_EVERY_SEC == 0 and second != last_collected:
                last_collected = second
                # cv2.imwrite('/tmp/' + str(cnt) + '.png', frame)
                
                #img_string = cv2.imencode('.jpg', frame)[1].tostring()
                #upload = s3.Bucket(bucket).put_object(Key='images/'+ save_path + str(cnt)+'.png', Body=img_string)
                #print(upload, ' : images/'+ save_path + str(cnt)+'.png')
                
                b64_string = encode_image(frame)
                input_payload = {"prompt": prompt, "image":b64_string}
                result = run_inference(blip_endpoint, input_payload)
                
                inference_results.append(result)
                cnt += 1
                if cnt == 50 :
                    print(cnt + ' / ' + video_len)
    return inference_results

def lambda_handler(event, context):
    # TODO implement
    print(event['requestPayload']['Records'][0]['s3'])
    bucket = event['requestPayload']['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['requestPayload']['Records'][0]['s3']['object']['key'], encoding='utf-8')

    s3.Bucket(bucket).download_file(key, '/tmp/input.mp4')
    
    
    results = extract_frames(bucket, key, '/tmp/input.mp4', SAMPLE_EVERY_SEC, True)
    
    response = {
        'statusCode': 200,
        'bucket':bucket,
        'key':key,
        'body': results,
        'interval': SAMPLE_EVERY_SEC
        }
        
    print(response)
    return response
