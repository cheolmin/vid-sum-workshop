import json
import boto3
import datetime
import os
from botocore.config import Config


bucket_name = 'cj-video-summarization-cm'

transcribe = boto3.client("transcribe")
s3 = boto3.resource('s3')
mediaconvert = boto3.client('mediaconvert')

retry_config = Config(
    region_name=os.environ.get("AWS_DEFAULT_REGION", None),
    retries={
        "max_attempts": 10,
        "mode": "standard",
    },
    read_timeout=1200,
)

# modelId = "anthropic.claude-instant-v1"  # (Change this to try different model versions)
modelId = "anthropic.claude-3-sonnet-20240229-v1:0"
accept = "application/json"
contentType = "application/json"

bedrock_runtime = boto3.client(service_name='bedrock-runtime', config=retry_config)

def bedrock_streamer(response):
    stream = response.get('body')
    answer = ""
    i = 1
    if stream:
        for event in stream:
            chunk = event.get('chunk')
            if chunk:
                chunk_obj = json.loads(chunk.get('bytes').decode())
                if "delta" in chunk_obj:
                    delta = chunk_obj['delta']
                    if "text" in delta:
                        text = delta['text']
                        print(text, end="")
                        answer += str(text)
                        i += 1
    return answer

def set_job(bucket, input_key, output_key, start_time, end_time):
    job_settings = {
        'Settings': {
            "Inputs": [
                {
                    "TimecodeSource": "ZEROBASED",
                    "VideoSelector": {},
                    "AudioSelectors": {
                        "Audio Selector 1": {
                            "DefaultSelection": "DEFAULT"
                        }
                    },
                    "FileInput": f's3://{bucket}/{input_key}',
                    "InputClippings": [
                        {
                            "StartTimecode": start_time,
                            "EndTimecode": end_time
                        }
                    ]
                }
            ],
            'OutputGroups': [{
                'CustomName': 'Output Group',
                'OutputGroupSettings': {
                    'Type': 'FILE_GROUP_SETTINGS',
                    'FileGroupSettings': {
                        'Destination': f's3://{bucket}/{output_key}'
                    }
                },
                "Outputs": [
                  {
                    "ContainerSettings": {
                      "Container": "MP4",
                      "Mp4Settings": {}
                    },
                    "VideoDescription": {
                      "CodecSettings": {
                        "Codec": "H_264",
                        "H264Settings": {
                          "RateControlMode": "QVBR",
                          "SceneChangeDetect": "TRANSITION_DETECTION",
                          "MaxBitrate": 5000000
                        }
                      }
                    },
                    "AudioDescriptions": [
                        {
                            "AudioSourceName": "Audio Selector 1",
                            "CodecSettings": {
                                "Codec": "AAC",
                                "AacSettings": {
                                    "Bitrate": 96000,
                                    "CodingMode": "CODING_MODE_2_0",
                                    "SampleRate": 48000
                                }
                            }
                        }
                    ]
                  }
                ],
                "CustomName": "weverse"
              }
            ],
            "TimecodeConfig": {
              "Source": "ZEROBASED"
            },
            "FollowSource": 1
          },
          "Role": "arn:aws:iam::600204363646:role/service-role/MediaConvert_Default_Role",
          "StatusUpdateInterval": "SECONDS_60",
          "BillingTagsSource": "QUEUE",
          "Queue": "arn:aws:mediaconvert:us-east-1:600204363646:queues/weverse-queue"
        }

    return job_settings

def merge_transcribe(transcribe_result):
    new_transcribe = []
    data = {'start_time': 0, 'end_time': 0, 'content': '', 'scene': ''}
    for transcribe in transcribe_result['items']:
        #print(transcribe)
        if transcribe['type'] != 'punctuation':
            data['content'] += transcribe['alternatives'][0]['content'] + ' '
            if data['start_time'] == 0:
                data['start_time'] = float(transcribe['start_time'])
            end_time = float(transcribe['end_time'])
        else:
            data['end_time'] = end_time
            new_transcribe.append(data)
            data = {'start_time': 0, 'end_time': 0, 'content': '', 'scene': ''}
    return new_transcribe

def check_transcribe_job(key):
    
    transcribe_job_name = 'job_' + key.split('/')[-1].split('.')[0]
    
    max_tries = 60
    while max_tries > 0:
        max_tries -= 1
        job = transcribe.get_transcription_job(TranscriptionJobName=transcribe_job_name)
        job_status = job["TranscriptionJob"]["TranscriptionJobStatus"]
        if job_status in ["COMPLETED", "FAILED"]:
            print(f"Job {transcribe_job_name} is {job_status}.")
            if job_status == "COMPLETED":
                print(
                    f"Download the transcript from\n"
                    f"\t{job['TranscriptionJob']['Transcript']['TranscriptFileUri']}."
                )
            break
        else:
            print(f"Waiting for {transcribe_job_name}. Current status is {job_status}.")
        time.sleep(10)

def blip_with_merge(blip_results, new_transcribe, SAMPLE_EVERY_SEC=2):
            
    for i, result in enumerate(blip_results):
        for transcribe in new_transcribe:
            if (transcribe['start_time'] <= ((2*i+1) * SAMPLE_EVERY_SEC)/2) \
                    and (transcribe['end_time'] >= ((2*i + 1) * SAMPLE_EVERY_SEC)/2):
                print('check', transcribe['start_time'], transcribe['end_time'])    
                if result not in transcribe['scene']:
                    transcribe['scene'] += result + ', '
                break

        print(i * SAMPLE_EVERY_SEC, result)
    return new_transcribe
    
def call_claude_sonet(prompt, base64_string=None, streaming=True, temperature=0, top_p=.999):
    if base64_string is None:
        prompt_config = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "temperature": temperature,
            "top_k": 350,
            "top_p": top_p,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
        }
    else:
        prompt_config = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "temperature": 0,
            "top_k": 350,
            "top_p": top_p,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": base64_string,
                            },
                        },
                        {"type": "text", "text": prompt},
                    ],
                }
            ],
        }

    body = json.dumps(prompt_config)

    modelId = "anthropic.claude-3-sonnet-20240229-v1:0"
    accept = "application/json"
    contentType = "application/json"

    if streaming:

        response = bedrock_runtime.invoke_model_with_response_stream(
            body=body, modelId=modelId, accept=accept, contentType=contentType
        )
        results = bedrock_streamer(response)
    else:
        response = bedrock_runtime.invoke_model(
            body=body, modelId=modelId, accept=accept, contentType=contentType
        )
        response_body = json.loads(response.get("body").read())
        results = response_body.get("content")[0].get("text")
    return results
    
def modifyFormat(result):
    x = result.splitlines(keepends=False)
    final_results = []
    for line in x:
        if line == '':
            continue
        text = line.split(',')
        print(text)
        if len(text) > 3:
            text = [text[0], text[1], ','.join(text[2:])]

        data = {}
        data['start_time'] = text[0].split('-')[1] if 'start_time' in text[0] else text[0]
        data['end_time'] = text[1].split('-')[1] if 'end_time' in text[1] else text[1]
        data['title'] = text[2].split('-')[1] if 'title' in text[2] else text[2]
        data['start_time'] = int(data['start_time'].split(':')[0]) if ':' in data['start_time'] else int(float(data['start_time']))
        if data['end_time'] == '끝':
            data['end_time'] = video_len
            data['end_time'] = int(data['end_time'])
        else:
            data['end_time'] = int(data['end_time'].split(':')[0]) if ':' in data['end_time'] else int(float(data['end_time']))
        data['start_time'] = (lambda x : '0' + x if len(x) < 8 else x)(str(datetime.timedelta(seconds = data['start_time'])))
        data['end_time'] = (lambda x : '0' + x if len(x) < 8 else x)(str(datetime.timedelta(seconds = data['end_time'])))
        data['start_time'] = data['start_time'] + ':00'
        data['end_time'] = data['end_time'] + ':00'

        final_results.append(data)
    print('\nfinal_result\n')
    print(final_results)
    return final_results

def lambda_handler(event, context):
    # TODO implement
    print(event['responsePayload'])
    bucket = event['responsePayload']['bucket']
    key = event['responsePayload']['key']
    blip_results = event['responsePayload']['body']
    interval = event['responsePayload']['interval']
    
    json_file = 'transcribe/'+key.split('/')[-1].split('.')[0]+'.json'
    check_transcribe_job(key)
    
    s3.Bucket(bucket).download_file(json_file, '/tmp/transcribe.json')
    
    transcribe_json = None
    with open('/tmp/transcribe.json') as f:
        transcribe_json = json.load(f)
        print('transcribe result', transcribe_json)
        
    if transcribe_json is not None:
        transcribe_result = merge_transcribe(transcribe_json)
        
        transcribe_result = blip_with_merge(blip_results, transcribe_result, interval)
    
    print(transcribe_result)
    
    prompt = """
    당신은 video analyst입니다. 아래의 <example>안에는 start_time, end_time, content, scene으로 구성된 자막이 있습니다. <condition></condition>에 해당하는 결과를 출력합니다. please think about the question within <condition></condition> XML tags.
    """

    example = """
    <example>
    {}
    </example>
    """.format(transcribe_result)
    
    condition = """
    <condition>
    대화의 주제에 대한 타임스탬프를 나열하고 내용을 요약해주세요. 타임스탬프는 오직 초단위만 가능합니다. 대화의 주제는 상세하게 나열해야 하며 시작과 끝이 자연스러워야 하고 빈 구간이 없어야합니다.
    </condition>
    """
    
    prompt = prompt + "\n" + example + "\n" + condition

    result = call_claude_sonet(prompt, streaming=False, temperature=1)
    print(result)
    
    condition = """
    최종 출력 결과는 오직 'start_time,end_time,title' 포맷으로 출력합니다. start_time, end_time은 반드시 초단위로 출력합니다. 유사한 주제를 하나의 주제로 통합해주세요.
    """
    prompt = result + "\n\n" + condition
    print('\n')
    print('\nafter')
    result = call_claude_sonet(prompt, temperature=0, top_p=0)
    
    print(result)
    
    final_results = modifyFormat(result)
    
    for final_result in final_results:
        print(final_result)
        result_path = key.split('/')[-1].split('.')[0]
        job_settings = set_job(bucket, input_key=key, output_key='result/'+result_path+'/'+final_result['title'], start_time=final_result['start_time'], end_time=final_result['end_time'])

        try:
            response = mediaconvert.create_job(**job_settings)
            job_id = response['Job']['Id']
            print(f'MediaConvert 작업이 제출되었습니다. 작업 ID: {job_id}')
        except Exception as e:
            print(f'오류 발생: {e}')
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
