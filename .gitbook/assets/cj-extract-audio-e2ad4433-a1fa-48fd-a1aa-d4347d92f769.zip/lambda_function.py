import json
import subprocess
import boto3
import urllib
import os

s3 = boto3.resource('s3')

def lambda_handler(event, context):
    print(event)
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')

    s3.Bucket(bucket).download_file(key, '/tmp/input.mp4')
    
    print('Audio File Info')
    subprocess.call(['ffmpeg', '-y', '-i', '/tmp/input.mp4', '/tmp/audio.mp3'])
    
    save_key = key.split('/')[-1]
    save_key = save_key.split('.')[0] + '.mp3'
    
    upload = s3.Bucket(bucket).put_object(Key='audios/'+save_key, Body=open('/tmp/audio.mp3', 'rb'))
    print(upload)
    
    return {
        'statusCode': 200,
        'body': event
    }